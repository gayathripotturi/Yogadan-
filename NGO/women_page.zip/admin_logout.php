<?php
session_start();
session_destroy();
header("refresh:2;url=admin_login.html");
echo"successfully logout";
?>